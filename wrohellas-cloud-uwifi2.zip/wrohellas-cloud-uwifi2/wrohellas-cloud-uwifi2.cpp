#include "wrohellas-cloud-uwifi2.h"
#include <Arduino.h>
#include <SPI.h>
#include <WiFiNINA.h>


char* ssid    = "";
char* pass    = "";
String wcip   = "";
int wccp      = "";
char* rsid    = "";
int status    = WL_IDLE_STATUS;
int PORT      = 0;

char server[13];

WiFiClient CLOUD;


//        'ERROR;00;',                    // Could not connect to wifi
//        'ERROR;01;',                    // Could connect to cloud server 
//        'ERROR;02;',                    // Error while creating mission
//        'ERROR;03;'                     // Error while finalising mission
char* debug_strings[4] = {'ERROR;00;', 'ERROR;01;', 'ERROR;02;', 'ERROR;03;'};


// Ορισμός σειριακής σύνδεσης του esp και καταχώρηση των στοιχείων σύνδεσης στο wifi
void wifiInit(char* init_ssid, char* init_pass) {
  ssid = init_ssid;
  pass = init_pass;
}


// Ορισμός παραμέτρων cloud
void cloudInit(String init_wcip, String init_wccp, char* init_rsid) {
  wcip = init_wcip;
  wccp = init_wccp.toInt();
  rsid = init_rsid;
}


// Σύνδεση στο διαδίκτυο
void wifiConnect() {
  status = WiFi.begin(ssid, pass);
  delay(4000);
}


// Έλεγχος σύνδεσης στο δίκτυο
bool wifiConnected() {
  if (status == WL_CONNECTED) {
    return true;
  } else {
    return false;
  }
}


// Δημιουργία αποστολής
String createMission(String missionType) {
  delay(1000);
  if (!wifiConnected()) {
    return debug_strings[0];
  } else {
    wcip.toCharArray(server, wcip.length()+1);
    CLOUD.connect(server, wccp);
    delay(2000);
    if (!CLOUD.connected()) {
      return debug_strings[1];
    } else {
      String buf = String(rsid) + ";" + missionType + ";";
      CLOUD.print(buf);
      delay(3000);
      buf = "";
      char ch;
      while (CLOUD.available()) {
        ch = CLOUD.read();
        buf += String(ch);
      }
      delay(1000);
      //Serial.println(buf);
      CLOUD.stop();
      if (buf == "") {
        return debug_strings[2];
      } else {
        return buf;
      }
    }
  }
}


// Ολοκλήρωση αποστολής
String completeMission(String missionId, String data) {
  delay(1000);
  if (!wifiConnected()) {
    return debug_strings[0];
  } else {
    wcip.toCharArray(server, wcip.length()+1);
    CLOUD.connect(server, wccp);
    delay(2000);
    if (!CLOUD.connected()) {
      return debug_strings[1];
    } else {
      String buf = missionId + ";" + data + ";";
      CLOUD.print(buf);
      delay(3000);
      buf = "";
      char ch;
      while (CLOUD.available()) {
        ch = CLOUD.read();
        buf += String(ch);
      }
      delay(1000);
      //Serial.println(buf);
      CLOUD.stop();
      if (buf == "") {
        return debug_strings[3];
      } else {
        return buf;
      }
    }
  }
}


// Διαχωρισμός αλφαριθμητικού
String getValue(String data, char separator, int index) {
  int found = 0;
  int strIndex[] = { 0, -1 };
  int maxIndex = data.length() - 1;
  for (int i = 0; i <= maxIndex && found <= index; i++) {
    if (data.charAt(i) == separator || i == maxIndex) {
      found++;
      strIndex[0] = strIndex[1] + 1;
      strIndex[1] = (i == maxIndex) ? i+1 : i;
    }
  }
  return found > index ? data.substring(strIndex[0], strIndex[1]) : "";
}


