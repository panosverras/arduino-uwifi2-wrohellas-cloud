#ifndef WROHELLAS-CLOUD-UWIFI2_H
#define WROHELLAS-CLOUD-UWIFI2_H

#include <Arduino.h>
#include <SPI.h>
#include <WiFiNINA.h>

// Ορισμός σειριακής σύνδεσης του esp και καταχώρηση των στοιχείων σύνδεσης στο wifi
void wifiInit(char* init_ssid, char* init_pass);

// Ορισμός παραμέτρων cloud
void cloudInit(String init_wcip, String init_wccp, char* init_rsid);

// Σύνδεση στο διαδίκτυο
void wifiConnect();

// Έλεγχος σύνδεσης στο δίκτυο
bool wifiConnected();

// Δημιουργία αποστολής
String createMission(String missionType);

// Ολοκλήρωση αποστολής
String completeMission(String missionId, String data);

// Διαχωρισμός αλφαριθμητικού
String getValue(String data, char separator, int index);

#endif
